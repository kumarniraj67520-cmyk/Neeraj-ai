package com.neeraj.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private TextView chat;
    private EditText input;
    private TextToSpeech tts;
    private static final int SPEECH_REQUEST = 42;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        makeUI();
        addBot("नमस्ते! मैं Neeraj AI हूँ। माइक दबाकर बोलो या नीचे लिखो। अभी माइक दबाना जरूरी है; यह वर्ज़न बैकग्राउंड में लगातार 'Hey Neeraj' नहीं सुनता।");
    }

    private void makeUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 22, 18, 18);
        root.setBackgroundColor(0xFF101426);

        TextView title = new TextView(this);
        title.setText("✦ Neeraj AI");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("हिंदी वॉइस असिस्टेंट · शुरुआती वर्ज़न");
        sub.setTextColor(0xFFB9C5E5);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        ScrollView scroll = new ScrollView(this);
        chat = new TextView(this);
        chat.setTextColor(0xFFF5F6FF);
        chat.setTextSize(16);
        chat.setPadding(12, 14, 12, 14);
        scroll.addView(chat);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1);
        cp.setMargins(0, 18, 0, 12);
        root.addView(scroll, cp);

        input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(0xFFFFFFFF);
        input.setHintTextColor(0xFFB5BED6);
        input.setHint("यहाँ लिखो...");
        root.addView(input, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(this);
        Button send = new Button(this);
        send.setText("भेजो");
        send.setOnClickListener(v -> handle(input.getText().toString()));
        Button mic = new Button(this);
        mic.setText("🎙 बोलो");
        mic.setOnClickListener(v -> listen());
        row.addView(send, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(mic, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        LinearLayout quick = new LinearLayout(this);
        for (String label : new String[]{"समय बताओ", "तारीख बताओ", "YouTube खोलो", "Google खोलो", "Maps खोलो"}) {
            Button b = new Button(this);
            b.setText(label);
            b.setOnClickListener(v -> handle(label));
            quick.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(quick);
        setContentView(root);
    }

    private void listen() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "कहिए, Neeraj AI सुन रहा है");
        try { startActivityForResult(i, SPEECH_REQUEST); }
        catch (Exception e) { Toast.makeText(this, "Voice input उपलब्ध नहीं है; लिखकर कमांड दें।", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) handle(r.get(0));
        }
    }

    private void handle(String raw) {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) return;
        input.setText("");
        addLine("आप: " + text);
        String q = text.toLowerCase(Locale.ROOT);
        if (q.contains("समय") || q.contains("टाइम") || q.contains("time")) {
            reply("अभी समय है " + new SimpleDateFormat("h:mm a", new Locale("hi", "IN")).format(new Date()));
        } else if (q.contains("तारीख") || q.contains("date")) {
            reply("आज " + new SimpleDateFormat("d MMMM yyyy", new Locale("hi", "IN")).format(new Date()) + " है।");
        } else if (q.contains("youtube") || q.contains("यूट्यूब")) {
            open("https://m.youtube.com/", "YouTube खोल रहा हूँ।");
        } else if (q.contains("google") || q.contains("गूगल")) {
            open("https://www.google.com/", "Google खोल रहा हूँ।");
        } else if (q.contains("maps") || q.contains("मैप") || q.contains("नक्शा")) {
            open("https://maps.google.com/", "Google Maps खोल रहा हूँ।");
        } else if (q.contains("लॉक") || q.contains("lock")) {
            reply("इस शुरुआती वर्ज़न में फोन लॉक करने की सुविधा नहीं है। Android की अनुमति और डिवाइस सेटअप के साथ इसे अलग से जोड़ा जा सकता है।");
        } else if (q.contains("अनलॉक") || q.contains("unlock")) {
            reply("मैं PIN, पैटर्न या पासवर्ड को बायपास करके फोन अनलॉक नहीं कर सकता।");
        } else if (q.contains("नमस्ते") || q.equals("hello") || q.equals("hi")) {
            reply("नमस्ते भाई! बताओ, क्या काम है?");
        } else if (q.contains("तुम कौन") || q.contains("तुम्हारा नाम")) {
            reply("मेरा नाम Neeraj AI है।");
        } else {
            reply("यह सवाल अभी मेरे शुरुआती वर्ज़न में उपलब्ध नहीं है। अभी समय, तारीख, YouTube, Google और Maps की कमांड इस्तेमाल कर सकते हो।");
        }
    }

    private void open(String url, String message) {
        reply(message);
        try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))); }
        catch (Exception e) { reply("लिंक नहीं खुल पाया।"); }
    }

    private void addBot(String text) { addLine("Neeraj AI: " + text); }
    private void addLine(String text) { chat.append(text + "\n\n"); }
    private void reply(String text) {
        addBot(text);
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "neeraj-reply");
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
